#!/usr/bin/env python3
"""Source audit for v2.33.29 accepted post-write PCM / video-master projection."""
from pathlib import Path
import sys


def req(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise RuntimeError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise RuntimeError(f"forbidden {label}: {needle}")


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: audit_v23329_accepted_pcm_video_master.py <morphe-root>")
    root = Path(sys.argv[1]).resolve()
    base = root / "extensions/youtube/src/main/java/app/spanishstudy/vot"
    probe = (base / "AudioVideoSyncProbe.java").read_text(encoding="utf-8")
    sherpa = (base / "SherpaNeuralShadow.java").read_text(encoding="utf-8")
    controller = (base / "SpanishStudyController.java").read_text(encoding="utf-8")
    vot = (root / "extensions/youtube/src/main/java/app/morphe/extension/youtube/patches/voiceovertranslation/VoiceOverTranslationPatch.java").read_text(encoding="utf-8")
    player = (root / "extensions/youtube/src/main/java/app/morphe/extension/youtube/patches/PlayerVolumePatch.java").read_text(encoding="utf-8")
    hook = (root / "patches/src/main/kotlin/app/morphe/patches/youtube/video/volume/PlayerVolumeHookPatch.kt").read_text(encoding="utf-8")

    # Bytecode-patch source must preserve write/move-result adjacency and move PCM observation post-write.
    req(hook, "resultInstruction.opcode != Opcode.MOVE_RESULT", "move-result verifier guard")
    req(hook, "writeIndex + 2", "post-write insertion point")
    post = hook.find("observeAudioTrackWriteResultForStudy(I)V")
    pcm = hook.find("observePcmBufferForStudy(Ljava/nio/ByteBuffer;)V")
    requested = hook.find("observeAudioTrackWriteRequestedForStudy(I)V")
    if min(post, pcm, requested) < 0 or not (post < pcm):
        raise RuntimeError("post-write callback ordering is not result-accounting then PCM observation")
    # The pre-write triple from v27 must be gone.
    forbid(hook,
           "observePcmBufferForStudy(Ljava/nio/ByteBuffer;)V\n                invoke-static/range { v$requestedBytesRegister",
           "pre-write PCM observation")

    for needle, label in [
        ("studyPcmWriteTrackAcceptedFrames", "track-local accepted-frame coordinate"),
        ("System.identityHashCode(track)", "AudioTrack identity coordinate reset"),
        ("studyPcmWriteLastAcceptedBytes", "one-shot accepted byte count"),
        ("studyPcmWriteLastAcceptedFrames", "one-shot accepted frame count"),
        ("SherpaNeuralShadow.observeAcceptedPcmBuffer", "accepted PCM handoff"),
        ("getPcmWriteTrackAcceptedFramesForStudy", "track coordinate diagnostic getter"),
    ]:
        req(player, needle, label)

    for needle, label in [
        ("public final int trackIdentity;", "render-anchor track identity"),
        ("public final int videoPerAudioPermille;", "render-anchor playback scale"),
        ("projectTrackFrameToVideoMs", "lock-free track-frame projection"),
        ("resetForVideoBoundary()", "new-video/full-close mapping reset"),
        ("invalidateContinuity()", "seek mapping invalidation"),
        ("audioVideoAdmissionAnchorTrackIdentity=", "track-identity diagnostics"),
        ("audioVideoLastProjectedPcmVideoMs=", "PCM projection diagnostics"),
    ]:
        req(probe, needle, label)

    for needle, label in [
        ("observeAcceptedPcmBuffer(ByteBuffer buffer", "accepted-slice neural entrypoint"),
        ("int end = src.position();", "post-write advanced-buffer endpoint"),
        ("int start = end - boundedBytes;", "exact accepted slice start"),
        ("src.limit(end);", "accepted slice end bound"),
        ("src.position(start);", "accepted slice start bound"),
        ("AudioVideoSyncProbe.projectTrackFrameToVideoMs", "video-master projection call"),
        ("long trackStartFrame = trackEndFrame - frames;", "track-frame slice coordinate"),
        ("nativeInferenceBusy", "native inference serialization"),
        ("speakerNeuralGate=v2.33.29-neural-only+accepted-postwrite+video-master-projection", "v29 neural gate marker"),
        ("speakerNeuralPcmFeed=post-audiotrack-write-accepted-slice-pcm16-16k-20s", "v29 PCM marker"),
        ("speakerNeuralAcceptedPcmAuthority=post-audiotrack-write-return-value+advanced-buffer-position", "accepted PCM authority marker"),
    ]:
        req(sherpa, needle, label)

    forbid(sherpa, "captureRenderAcceptedInputFrames + frames > allowedInputFrames", "v28 full-buffer render-credit gate")
    forbid(sherpa, "if ((((int) captureBuffers) & 3) != 0) return;", "old stride-4 gate")
    forbid(sherpa, "getPlaybackHeadPosition()", "AudioTrack API on neural callback")
    forbid(sherpa, "getTimestamp(", "AudioTimestamp API on neural callback")
    forbid(sherpa, "VideoInformation", "YouTube API on neural callback")
    forbid(sherpa, "getVideoTime", "YouTube API on neural callback")
    forbid(sherpa, ".interrupt()", "native worker interruption")
    forbid(sherpa, "LS-EEND", "premature streaming diarizer")
    forbid(sherpa, "FluidAudio", "premature streaming diarizer")

    # Per-video reset may clear capture state but must not falsely mark a still-running native call idle.
    reset_pos = sherpa.find("public static void resetCaptureForVideo()")
    if reset_pos < 0:
        raise RuntimeError("missing resetCaptureForVideo")
    reset_end = sherpa.find("private static", reset_pos + 1)
    reset_block = sherpa[reset_pos: reset_end if reset_end > reset_pos else len(sherpa)]
    if "nativeInferenceBusy = false" in reset_block:
        raise RuntimeError("per-video reset incorrectly clears nativeInferenceBusy")

    for needle, label in [
        ("AudioVideoSyncProbe.resetForVideoBoundary();", "new-video/full-close visible reset"),
        ("AudioVideoSyncProbe.invalidateContinuity();", "explicit seek invalidation"),
        ("VideoSessionClock.markExplicitSeek();", "master-clock seek boundary"),
    ]:
        req(vot, needle, label)
    if vot.count("AudioVideoSyncProbe.resetForVideoBoundary();") < 2:
        raise RuntimeError("expected resetForVideoBoundary on both new-video and full-close paths")

    for needle, label in [
        ("Spanish Dub Study v2.33.29 accepted-PCM video-master timeline diagnostics", "v29 diagnostics header"),
        ("pcmAdmission=exact-android-accepted-postwrite-slice-v23329", "v29 admission declaration"),
        ("pcmLifecycleReset=new-video+full-close-visible-reset;pause-keep;seek-continuity-invalidate", "lifecycle policy"),
        ("nativeInferenceLifecycle=retain-model+epoch-discard+single-native-worker-no-interrupt", "native lifecycle policy"),
        ("pcmWriteObserverTiming=after-write+move-result+accepted-result-before-renderer-next-instruction", "post-write observer declaration"),
    ]:
        req(controller, needle, label)

    print("PASS v2.33.29 accepted PCM/video-master source audit")
    print("- AudioTrack.write remains adjacent to move-result; PCM observation is post-write")
    print("- Sherpa receives only the exact positive Android-accepted ByteBuffer slice")
    print("- track-local accepted frame coordinates project onto authoritative YouTube videoMs")
    print("- new video/full close reset visible mapping; pause keeps state; seek invalidates continuity")
    print("- retained native diarizer is serialized; epoch invalidation never interrupts JNI")
    print("- translation, TTS, subtitle timing, voice routing, LS-EEND remain untouched")


if __name__ == "__main__":
    main()
